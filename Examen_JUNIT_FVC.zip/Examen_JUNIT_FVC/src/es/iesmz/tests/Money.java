/*Nombre: Fran Vidal Chiclana*/

package es.iesmz.tests;

import java.util.Scanner;

import static java.lang.Float.parseFloat;

public class Money {

    static float change(TipoMoneda origen, TipoMoneda destino, float money){
        float EUR = 1f;
        float USD = 1f;
        float GBP = 1f;

        if(EUR == 1f) {
            USD = EUR + 1.18798f;
            GBP = EUR + 0.857839f;
        }
        if(USD == 1f) {
            EUR = USD + 0.841815f;
            GBP = USD + 0.20f;
        }
        if(GBP == 1f){
            EUR = GBP + 1.165826f;
            USD = GBP + 1.24f;
        }

        if(money > 0){
            return money;
        }else {
            return -1;
        }

    }
}
