package es.iesmz.tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class MoneyTests {
    @Test
    void testCambioMonedaEUR_A_USD(){
        assertEquals(28.37f, Money.change(TipoMoneda.EUR, TipoMoneda.USD, 23.88f));
    }

    @Test
    void testCambioMonedaGBP_A_EUR(){
        assertEquals(1165.83f, Money.change(TipoMoneda.GBP, TipoMoneda.EUR, 1000.0f));
    }

    @Test
    void testCambioMonedaEUR_A_GBP(){
        assertEquals(201.21f, Money.change(TipoMoneda.GBP, TipoMoneda.EUR, 234.56f));

    }

    @Test
    void testCambioMonedaUSD_A_EUR(){
        assertEquals(37.51f, Money.change(TipoMoneda.GBP, TipoMoneda.EUR, 44.56f));

    }

    @Test
    void testCambioMonedaUSD_A_GBP(){
        assertEquals(138.49f, Money.change(TipoMoneda.GBP, TipoMoneda.EUR, 100.0f));

    }

    @Test
    void testCambioMonedaPTS_A_EUR(){
        assertEquals(722.14f, Money.change(TipoMoneda.GBP, TipoMoneda.EUR, 1000.0f));

    }

    @Test
    void testCambioMonedaEUR_A_PTS(){
        assertEquals(-1f, Money.change(TipoMoneda.GBP, TipoMoneda.EUR, 100.0f));

    }

    @Test
    void testCambioMonedaUSD_A_EUR2(){
        assertEquals(-1f, Money.change(TipoMoneda.GBP, TipoMoneda.EUR, -167.34f));

    }
}
