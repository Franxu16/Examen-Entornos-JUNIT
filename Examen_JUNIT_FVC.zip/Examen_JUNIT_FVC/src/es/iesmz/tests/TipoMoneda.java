package es.iesmz.tests;

public enum TipoMoneda {
    GBP, EUR, PTS, USD;
}
